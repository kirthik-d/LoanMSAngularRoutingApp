export class Contact {
    Id;
    Full_Name;
    Email;
    Message;
}
