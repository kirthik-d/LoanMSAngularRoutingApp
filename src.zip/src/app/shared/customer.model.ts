export class Customer {
    BorrowerId;
    BorrowerName;
    BorrowerContact;
    BorrowerAddress;
    PropertyNo;
}