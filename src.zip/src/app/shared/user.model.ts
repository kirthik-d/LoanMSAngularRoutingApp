export class User {
    Id;
    UserNameOrEmail;
    Password;
    Confirm_Password;
}
