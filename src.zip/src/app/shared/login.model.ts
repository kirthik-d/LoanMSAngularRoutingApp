export class Login {
    userName;
    password;
}
