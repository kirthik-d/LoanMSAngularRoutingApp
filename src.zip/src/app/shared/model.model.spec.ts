import { Contact } from './model.model';

describe('Model', () => {
  it('should create an instance', () => {
    expect(new Contact()).toBeTruthy();
  });
});
