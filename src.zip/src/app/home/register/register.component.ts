import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { SignupService } from 'src/app/shared/signup.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  type:string ="password";
  signUpForm!: FormGroup;
  constructor(public objSrv:SignupService) { }

  ngOnInit(): void {
    this.resetForm();
  }
  resetForm(form?:NgForm) {
    if(form!=null)
    {
      form.form.reset();
    }
    else {
      this.objSrv.ppData={Id:0, UserNameOrEmail: '', Password:'', Confirm_Password:''};
    }
  }
  onSubmit(form:NgForm)
  {
    this.objSrv.postUser().subscribe(
        res=>{this.resetForm(form);
        this.objSrv.getUser();
        alert("Record Insertion Success!!!");
        },
        err=>{alert('Error!!!'+err);}
    )
  }
  
  onSignup(){
    console.log(this.objSrv.ppData);
    if(this.objSrv.ppData.Id==0){
      //perform signup
      this.objSrv.postUser().subscribe(
        res=>{ 
        this.objSrv.getUser();
        alert("Record Insertion Success!!!");
        },
        err=>{alert('Error!!!'+err);}
    )
      
    }else{
      this.validateAllFormFields(this.signUpForm)
      //throw error
    }
  }
  private validateAllFormFields(formGroup:FormGroup){
    Object.keys(formGroup.controls).forEach(field=>{
      const control = formGroup.get(field);
      if(control instanceof FormControl){
        control.markAsDirty({onlySelf:true})
      }else if(control instanceof FormGroup){
        this.validateAllFormFields(control)
      }
    })

}

}